Thanks for downloading!

This font is free for PERSONAL USE only.
If you need an extended license or corporate license, please contact me at ghuroba.designstudio@gmail.com

Pplease follow our works on:
https://www.instagram.com/ghurobastudio/
https://www.behance.net/ghurobastudio

Best Regards,
Ghuroba Studio
